import path from 'node:path';
import util from 'node:util';
import { exec } from 'node:child_process';

import { build } from 'tsup';
//type TsupBuildOptions = Parameters<typeof build>[0];

import fse from 'fs-extra';
import type { IDependencyMap, IPackageJson } from 'package-json-type';
import pc from "picocolors"

const execAsync = util.promisify(exec);

const distFolder = path.join(__dirname, 'dist');

(async () => {
    try {
        await fse.ensureDir(distFolder);

        await Promise.all([
            buildLib('browser'),
            buildLib('cjs'),
            buildLib('esm'),
            buildCli(),
            buildDts(),
            copyPackageJson()
        ]);

    } catch (error) {
        console.error('Build failed: ', error, error.stack);
    }
})();

async function buildLib(type: 'browser' | 'cjs' | 'esm') {
    const isBrowser = type === 'browser';
    const isEsm = type === 'esm';

    const subdir = type === 'cjs' ? '' : type;
    let outfile = path.join('dist', subdir, 'index.' + (isEsm ? 'mjs' : 'js'));
    console.log(`Building library to ${pc.blueBright(outfile)} ...`);
    outfile = path.join(__dirname, outfile);

    const target = isBrowser ? 'es2015' : 'es2017';

    await build({
        entry: ['src/index.ts'],
        outDir: '',
        format: isBrowser ? 'iife' : type,
        silent: true,
        globalName: isBrowser ? 'LhqGenerators' : undefined,
        target: target,
        minify: false,
        splitting: isEsm ? false: undefined,
        platform: isBrowser ? 'browser' : 'node',
        sourcemap: false,
        dts: false,
        clean: false,
        tsconfig: isBrowser ? 'tsconfig.browser.json' : 'tsconfig.json',
        esbuildOptions(esOpts, _) {
            esOpts.target = target;
            esOpts.outfile = outfile;
        },
    });
}
// async function buildLib(opts: Partial<TsupBuildOptions> & {outfile: string}) {
//     let outfile = path.join('dist', 'lhqgenerators.js');
//     console.log(`Building library to ${pc.blueBright(outfile)} ...`);

//     outfile = path.join(__dirname, outfile);

//     await build({
//         entry: ['src/index.ts'],
//         outDir: '',
//         format: 'iife',
//         silent: true,
//         globalName: 'LhqGenerators',
//         target: 'es2015',
//         minify: false,
//         platform: 'browser',
//         sourcemap: false,
//         dts: false,
//         clean: false,
//         tsconfig: 'tsconfig.json',
//         esbuildOptions(options, _) {
//             options.target = 'es2015';
//             options.outfile = outfile;
//         },
//     });
// }

async function buildDts() {
    let dtsFile = path.join('dist', 'index.d.ts');
    console.log(`Building dts to ${pc.blueBright(dtsFile)} ...`);

    dtsFile = path.join(__dirname, dtsFile);

    await build({
        entry: ['src/index.ts'],
        outDir: '',
        dts: true,
        clean: false,
        silent: true,
        tsconfig: 'tsconfig.dts.json',
        esbuildOptions(esOpts) {
            esOpts.outfile = dtsFile;
        }
    });

    await fse.move(dtsFile, path.join(__dirname, 'dist', 'types', 'index.d.ts'));
}

async function buildCli() {
    let outfile = path.join('dist', 'cli.js');
    console.log(`Building CLI to ${pc.blueBright(outfile)} ...`);
    outfile = path.join(__dirname, outfile);

    const bundle = false;
    const external = bundle ? ['path', 'fs', 'os'] : undefined;

    await build({
        entry: ['src/cli.ts'],
        outDir: '',
        format: 'cjs',
        silent: true,
        bundle: bundle,
        skipNodeModulesBundle: false,
        platform: 'node',
        external: external,
        minify: false,
        splitting: false,
        sourcemap: false,
        dts: false,
        clean: false,
        //tsconfig: 'tsconfig.build.json',
        esbuildOptions(options) {
            options.outfile = outfile;
            options.platform = 'node';
            options.external = external;
            /* options.alias = {
                'src/index': 'index'
            } */
        },
    });
}

async function copyPackageJson() {
    await execAsync('pnpm version patch', { cwd: __dirname });

    const sourcePackageFile = path.join(__dirname, 'package.json');
    const packageJson: Partial<IPackageJson> = await fse.readJson(sourcePackageFile, { encoding: 'utf-8' });

    console.log('Updated local version to ' + pc.blueBright(packageJson.version));

    const devDependenciesToCopy = [
        'commander', 'fs-extra', 'glob', 'picocolors', '@commander-js/extra-typings',
        '@xmldom/xmldom', 'xpath', 'zod-to-json-schema', 'zod-validation-error'
    ];

    const devDependencies = Object.assign({}, packageJson.dependencies, Object.fromEntries(
        Object.entries(packageJson.devDependencies!).filter(([key]) => devDependenciesToCopy.includes(key))
    ));


    const newPackageJson: Partial<IPackageJson> = {
        name: packageJson.name,
        version: packageJson.version,
        author: packageJson.author,
        description: packageJson.description,
        engines: packageJson.engines,
        dependencies: devDependencies,
        peerDependencies: {
            'typescript': packageJson.peerDependencies?.typescript!,
        },
        types: 'types/index.d.ts',
        bin: {
            lhqcmd: 'cli.js'
        },
        main: "./index.js",
        browser: "./browser/index.js",
        module: "./esm/index.mjs",
    }

    let targetPackageFile = path.join('dist', 'package.json');
    console.log('Copying package.json to ' + pc.blueBright(targetPackageFile));

    targetPackageFile = path.join(__dirname, targetPackageFile);
    await fse.writeJson(targetPackageFile, newPackageJson, { encoding: 'utf-8', spaces: 2 });
}