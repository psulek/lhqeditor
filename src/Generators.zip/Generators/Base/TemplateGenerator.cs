using System.IO;
using LHQ.Data;
using LHQ.Data.Templating.Settings;
using LHQ.Data.Templating.Templates;
using LHQ.Utils.Utilities;

namespace LHQ.Generators
{
    public abstract class TemplateGenerator<TSettings>: DisposableObject where TSettings : CodeGeneratorTemplate
    {
        protected readonly ModelContext ModelContext;
        protected readonly string ModelFileName;

        protected TemplateGenerator(ModelContext modelContext, string modelFileName)
        {
            ModelContext = modelContext;
            ModelFileName = modelFileName;
            TargetFolder = Path.GetDirectoryName(modelFileName);
        }
        
        protected string TargetFolder { get; }
        
        public TSettings Settings { get; set; }

        public abstract void Generate();

        protected override void DoDispose()
        {
            ModelContext?.Dispose();
        }

        protected void RenderViewToFile<T, VM>(GeneratorSettingsBase generatorSettings, string fileName) where T : TemplateView<VM> where VM : TemplateViewModel
        {
            if (!generatorSettings.Enabled)
            {
                return;
            }
            
            var viewModel = (VM)System.Activator.CreateInstance(typeof(VM), ModelContext, generatorSettings);
            var templateView = (T)System.Activator.CreateInstance(typeof(T), viewModel);
            string content = templateView!.Render();

            var folder = string.IsNullOrEmpty(generatorSettings.OutputFolder)
                ? TargetFolder
                : Path.Combine(TargetFolder, generatorSettings.OutputFolder);

            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            fileName = Path.Combine(folder, fileName);
            File.WriteAllText(fileName, content);
        }
    }
}