using RazorBlade;
using RazorBlade.Support;

namespace LHQ.Generators
{
    public abstract class TemplateView<T> : PlainTextTemplate<T> where T: TemplateViewModel
    {
        [TemplateConstructor]
        protected TemplateView(T model) : base(model)
        {
        }
    }
}