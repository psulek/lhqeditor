﻿using System;
using LHQ.Data;
using LHQ.Data.Templating.Settings;

namespace LHQ.Generators
{
    public class TemplateViewModel
    {
        public TemplateViewModel(ModelContext modelContext, GeneratorSettingsBase settings)
        {
            ModelContext = modelContext;
            Settings = settings;
        }

        public Model ModelRoot => ModelContext.Model;

        public LanguageElement PrimaryLanguage => ModelContext.GetPrimaryLanguage();

        public ModelContext ModelContext { get; }

        public GeneratorSettingsBase Settings { get; }

        protected virtual string GetCommentForResourceProperty(ResourceElement resource)
        {
            var primaryResourceValue = resource.FindValueByLanguage(PrimaryLanguage.Name);
            string propertyComment = primaryResourceValue != null && !string.IsNullOrEmpty(primaryResourceValue.Value)
                ? primaryResourceValue.Value
                : resource.Description;

            if (propertyComment == null)
            {
                propertyComment = string.Empty;
            }

            bool trimmed = false;
            var idxNewLine = propertyComment.IndexOf(Environment.NewLine);

            if (idxNewLine == -1)
            {
                idxNewLine = propertyComment.IndexOf('\n');
            }

            if (idxNewLine == -1)
            {
                idxNewLine = propertyComment.IndexOf('\r');
            }

            if (idxNewLine > -1)
            {
                propertyComment = propertyComment.Substring(0, idxNewLine);
                trimmed = true;
            }

            if (propertyComment.Length > 80)
            {
                propertyComment = propertyComment.Substring(0, 80);
                trimmed = true;
            }

            if (trimmed)
            {
                propertyComment += "...";
            }

            propertyComment = propertyComment.Replace('\t', ' ');

            return propertyComment;
        }
    }
}