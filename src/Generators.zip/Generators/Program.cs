﻿using System;

namespace LHQ.Generators;

public static class Program
{
    [STAThread]
    public static void Main(string[] args)
    {
        
    }
}