﻿using LHQ.Data;
using LHQ.Data.Templating.Templates.NetCore;
using LHQ.Generators.NetCore;

namespace LHQ.Generators.TemplateGenerators
{
    [TemplateGeneratorId("NetCoreResxCsharp01")]
    public class CSharpNetCoreTemplateGenerator : TemplateGenerator<NetCoreResxCsharp01Template>
    {
        public CSharpNetCoreTemplateGenerator(ModelContext modelContext, string modelFileName) : base(modelContext, modelFileName)
        {}

        public override void Generate()
        {
            // var viewModel = new CSharpTemplateViewModel(ModelContext, Settings.CSharp);
            // new CSharpTemplateView(viewModel).Render();

            var modelName = ModelContext.Model.Name;
            
            RenderViewToFile<CSharpTemplateView, CSharpTemplateViewModel>(Settings.CSharp, modelName + ".gen.cs");
        }
    }
}