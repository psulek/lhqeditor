﻿using System;
using System.Collections.Generic;
using System.Linq;
using LHQ.Data;
using LHQ.Data.Extensions;
using LHQ.Data.Templating.Settings;
using LHQ.Data.Templating.Settings.NetCore;

namespace LHQ.Generators.NetCore
{
    public class CSharpTemplateViewModel : TemplateViewModel
    {
        private Dictionary<ResourceElement, ResourceInfo> AllResources { get; set; }

        private ResourceElementList _rootResources;
        
        public CSharpTemplateViewModel(ModelContext modelContext, GeneratorSettingsBase settings)
            : base(modelContext, settings)
        {
            Settings = (CSharpGeneratorSettings)settings;

            FlattenAllResources();

            NamespaceName = Settings.RootNamespace;
            ModelName = ModelRoot.Name;
            ModelClassName = ModelName;
            ResourcesNamespace = NamespaceName;
            if (!string.IsNullOrEmpty(settings.OutputFolder)) {
                ResourcesNamespace += "." + settings.OutputFolder.Replace("\\", ".");
            }
            
            ModelClassNameWithNamespace = NamespaceName + "." + ModelClassName;
            AvailableCultures = string.Join(",", ModelRoot.Languages.Select(x => "\"" + x.Name + "\""));

            KeysClassName = ModelName + "Keys";
            StringLocalizerClassName = ModelName + "Localizer";
        }

        public string NamespaceName { get; }

        public string AvailableCultures { get; }

        public string ModelClassNameWithNamespace { get; }

        public string StringLocalizerClassName { get; }

        public string KeysClassName { get; }

        public string ResourcesNamespace { get; }

        public string ModelClassName { get; }

        public string ModelName { get; }

        public new CSharpGeneratorSettings Settings { get; }

        private void FlattenAllResources()
        {
            _rootResources = new ResourceElementList(ModelRoot.Resources.Where(x => x.ParentKey == null).ToList());
            AllResources = _rootResources.ToDictionary(x => x, x => new ResourceInfo(x));
            IterateCategories(ModelRoot.Categories, string.Empty, string.Empty, _rootResources);
        }

        private void IterateCategories(CategoryElementList categories, string parentsPath, string parentsPathSep, ResourceElementList parentResources)
        {
            foreach(var category in categories.OrderByName())
            {
                var newparentsPath = parentsPath + category.Name;
                var newparentsPathSep = string.IsNullOrEmpty(parentsPathSep) ? category.Name : parentsPathSep + "." + category.Name;

                if (parentResources.ContainsByName(category.Name, true)) 
                {
                    throw new ApplicationException(string.Format("Could not generate C# code! Resource and category name '{0}' could not be same for parent '{1}'!", category.Name, parentsPathSep ?? ""));
                }

                if (category.Categories.Count > 0)
                {
                    IterateCategories(category.Categories, newparentsPath, newparentsPathSep, category.Resources);
                }

                foreach(var resource in category.Resources.OrderByName())
                {
                    var resourceInfo = new ResourceInfo(resource);
                    resourceInfo.ParentsPath = newparentsPath;
                    resourceInfo.ParentsPathWithSep = newparentsPathSep;
                    AllResources.Add(resource, resourceInfo);
                }
            }
        }

        #region ResourceInfo

        private class ResourceInfo
        {
            public ResourceElement Resource { get; set; }
            public string ParentsPath { get; set; }
            public string ParentsPathWithSep { get; set; }

            public ResourceInfo(ResourceElement resource)
            {
                Resource = resource;
            }

            public string GetResourceKey(bool withSeparator)
            {
                if (withSeparator)
                {
                    return string.IsNullOrEmpty(ParentsPathWithSep)
                        ? Resource.Name
                        : ParentsPathWithSep + "." + Resource.Name;
                }

                return string.IsNullOrEmpty(ParentsPath) ? Resource.Name : ParentsPath + Resource.Name;
            }
        }

        #endregion
    }
}