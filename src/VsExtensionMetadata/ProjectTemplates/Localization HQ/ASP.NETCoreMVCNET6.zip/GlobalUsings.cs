﻿global using System.ComponentModel.DataAnnotations;
global using System.Globalization;
global using Microsoft.AspNetCore.Mvc;
global using Microsoft.AspNetCore.Localization;
global using $safeprojectname$;
global using $safeprojectname$.DataAnnotations;
global using $safeprojectname$.Models;

global using ScaleHQ.AspNetCore.LHQ;