﻿using System.Globalization;
using $safeprojectname$;

Console.WriteLine(Strings.Messages.Welcome);

string cultures = string.Join(",", StringsContext.Instance.AvailableCultures);

string? culture = null;
while (culture == null)
{
    Console.WriteLine($"Please select culture: (available: {cultures})");
    var input = Console.ReadLine();
    if (!string.IsNullOrEmpty(input) && StringsContext.Instance.AvailableCultures.Contains(input))
    {
        culture = input;
    }
}

CultureInfo cultureInfo = new(culture);
StringsContext.Instance.Culture = cultureInfo;

Console.WriteLine($"\nSelected culture: {cultureInfo.DisplayName} ({culture})\n");

Console.WriteLine(Strings.Messages.Title(Environment.UserName, "LHQ Editor", DateTime.Now.ToString("F")));

Console.ReadLine();