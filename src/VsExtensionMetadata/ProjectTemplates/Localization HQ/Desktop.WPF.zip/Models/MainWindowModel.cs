﻿using ScaleHQ.WPF.LHQ;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Threading;

namespace $safeprojectname$.Models
{
    public class MainWindowModel : INotifyPropertyChanged
    {
        private DispatcherTimer timer;
        private LocalizedActualTime _actualTime;

        public MainWindowModel()
        {
            WindowsUser = Environment.UserName;

            var activeCultureName = StringsContext.Instance.Culture.Name;

            AvailableCultures = new ObservableCollection<CultureViewModel>(StringsContext.Instance.AvailableCultures
                .Select(x => new CultureViewModel(x, x == activeCultureName, this)));

            ActualTime = new LocalizedActualTime();

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += OnTimerTick;
            timer.Start();
        }

        public string WindowsUser { get; set; }

        public ObservableCollection<CultureViewModel> AvailableCultures { get; set; }

        public LocalizedActualTime ActualTime
        {
            get
            {
                return _actualTime;
            }
            set
            {
                _actualTime = value;
                OnPropertyChanged(nameof(ActualTime));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private void OnTimerTick(object sender, EventArgs e)
        {
            OnPropertyChanged(nameof(ActualTime));
        }

        internal void ActiveCultureChanged()
        {
            foreach (var cultureViewModel in AvailableCultures)
            {
                cultureViewModel.RefreshProperties();
            }
        }
    }

    public class LocalizedActualTime : DynamicLocalizableResource
    {
        public override string GetLocalizedString(object parameter)
        {
            return Strings.Timer.ActualTime(DateTime.Now.ToString());
        }
    }
}