﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Neo.Localization")]
[assembly: AssemblyProduct("Neo.Localization")]

[assembly: ComVisible(false)]
[assembly: Guid("a78c7a4e-75e4-4903-bcc7-6eaadd75d971")]
