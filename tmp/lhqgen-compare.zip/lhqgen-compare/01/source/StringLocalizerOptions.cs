﻿// using System.Resources;
// using Neo.Web.Localization;

// namespace Neo.Localization
// {
//    public class StringLocalizerOptions : IStringLocalizerOptions
//    {
//        public ResourceManager ResourceManager { get; } = StringsMetadata.ResourceManager;
//    }
// }