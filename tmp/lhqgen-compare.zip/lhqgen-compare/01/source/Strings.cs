﻿using Neo.Web.Localization;

namespace Neo.Localization
{
    public partial class Strings : ITypedStrings
    {
        public static partial class Shared
        {
            public static string GetEnabledDisabledAction(bool enabled)
            {
                return enabled ? EnableAction : DisableAction;
            }

            public static string GetEnabledDisabledStatus(bool enabled)
            {
                return enabled ? StatusEnabled : StatusDisabled;
            }
        }
    }
}